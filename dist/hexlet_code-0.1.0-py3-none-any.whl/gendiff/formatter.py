from gendiff.diff_logic import ADDED, DELETED, UNCHANGED, UPDATED, NESTED

MIDDLE_TEMPLATE = '{}{} {}: {}'
FINAL_TEMPLATE = '{{\n{}\n}}'
START_TEMPLATE = '{}{} {}: {{'
END_TEMPLATE = '{}  }}'

MAX_INDENT = 4
SIGN_INDENT = 2


def render_nodes(diff, level=1):
    """
    diff: list of dict
    diff is internal structure of difference between two configuration files
    """
    diff.sort(key=lambda node: node['key'])
    result = []
    for node in diff:
        if node['node_type'] == ADDED:
            result.append(
                create_line(level, '+', node['key'], node['value']['new_value'])
                )
        elif node['node_type'] == DELETED:
            result.append(
                create_line(level, '-', node['key'], node['value']['old_value'])
            )
        elif node['node_type'] == UNCHANGED:
            result.append(
                create_line(level, ' ', node['key'], node['value']['old_value'])
            )
        elif node['node_type'] == UPDATED:
            result.append(
                create_line(level, '-', node['key'], node['value']['old_value'])
            )
            result.append(
                create_line(level, '+', node['key'], node['value']['new_value'])
            )
        elif node['node_type'] == NESTED:
            result.extend([
                START_TEMPLATE.format(get_indent(level), ' ', node['key']),
                render_nodes(node['children'], level=level),
                END_TEMPLATE.format(get_indent(level))
            ])
    
    return '\n'.join(result)

def create_line(level, sign, key, value):
    result = []
    indent = get_indent(level)
    level += 1
    
    if isinstance(value, dict):
        result.extend([
            START_TEMPLATE.format(indent, sign, key),
            formate_dict_value(value, level),
            END_TEMPLATE.format(indent)
        ])
    else:
        result.append(
            MIDDLE_TEMPLATE.format(indent, sign, key, get_valid_value(value))
        )
    
    return '\n'.join(result)

def formate_dict_value(dict_value, level):
    result = []
    for key, value in dict_value:
        create_line(level, ' ', key, value)
    return '\n'.join(result)


def get_stylish(diff):
    result = render_nodes(diff)
    # return FINAL_TEMPLATE.format('\n'.join(result))
    return result
    

def get_valid_value(value):
    if isinstance(value, bool):
        valid_value = str(value).lower()
    elif value is None:
        valid_value = 'null'
    # elif isinstance(value, list):
    #     value = render_nodes(value)
    else:
        valid_value = str(value)
    return valid_value

def get_indent(level):
    return ' ' * (MAX_INDENT * level - SIGN_INDENT)